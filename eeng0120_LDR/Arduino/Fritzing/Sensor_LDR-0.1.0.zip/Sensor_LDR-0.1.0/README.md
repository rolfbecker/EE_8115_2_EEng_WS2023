Sensor LDR
============
Gets the amount of ambient light.

Version 1.0.0 Oct 2015
Copyright 2015 by Diego de los Reyes http://diegorys.es

For use this library, you must connect a LDR sensor
to your Arduino Board.